package exercicios_easy;

import javax.swing.*;

public class Exec2 {
    public static void main(String[] args) {
        String palavra;
        palavra= JOptionPane.showInputDialog("digite sua palavra aqui");
        System.out.println("a palavra é: " + palavra);
    }
}
