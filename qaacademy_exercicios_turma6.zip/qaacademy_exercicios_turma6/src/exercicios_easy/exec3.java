package exercicios_easy;

import javax.swing.*;

public class exec3 {
    public static void main(String[] args) {
        String nome;
        String sobrenome;
        nome= JOptionPane.showInputDialog("nome ");
        sobrenome= JOptionPane.showInputDialog("Sobrenome ");
        System.out.println("o nome é: " + sobrenome +" "+ nome);
    }
}

//    Faça um algoritmo para ler dois valores, armazenar em variáveis, e exibir os valores das variáveis, trocados.
//
//
//        Ex1:
//        Inicio Algoritmo
//        Declarar variáveis do tipo texto : nome, sobrenome;
//        nome = Ler(“Silas”);
//        sobrenome = Ler(“Leão”);
//        Exibir: “O nome é ” + sobrenome + nome;
//        Fim Algoritmo
