package exercicios_easy;

public class exec7 {
    public static void main(String[] args) {

    }
}
